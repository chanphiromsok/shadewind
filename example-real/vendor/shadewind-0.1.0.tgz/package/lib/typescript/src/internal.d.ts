import { type ColorValue } from 'react-native';
/** Debug report: where a stale colour comes from. All counts refer to backgroundColor of registered views. */
export type InspectReport = {
    theme: string;
    registered?: number;
    inTree?: number;
    notInTree?: number;
    treeMatchesExpected?: number;
    /** iOS: registered views whose UIView.backgroundColor equals the expected theme colour. */
    nativePropsMatchExpected?: number;
    /** iOS: registered views whose layer was painted with the expected theme colour. */
    layerMatchesExpected?: number;
    samples?: string;
};
/** Native-side breakdown of one setTheme call, in milliseconds. */
export type ThemeTimings = {
    views: number;
    /** 'hook' strategy: time spent finding views that need an update inside the commit hook. */
    scanMs: number;
    /** 'hook' strategy: time spent building typed props and cloning the nodes. */
    cloneMs: number;
    /** 'hook' strategy: part of cloneMs spent building the typed props. */
    propsMs: number;
    /** 'hook' strategies: views whose props came from the per-view cache instead of being rebuilt. */
    reused?: number;
    /** 'hook' strategies: views whose node was taken from the pre-built buffer (no clone on the critical path). */
    precloned?: number;
    /** 'hook' strategies: why nodes missed the pre-built buffer, as notOurs/noBuffer/source/props/children counts. */
    misses?: string;
    /** 'hookAsync': time from the previous setTheme call until the main thread finished mounting it. */
    visualMs?: number;
    collectMs: number;
    directMs: number;
    commitMs: number;
    totalMs: number;
};
/**
 * How a theme change reaches the screen. Unknown names throw.
 * - 'hookAsync' (default): typed props are applied inside a commit hook (so every commit, React's too, keeps the theme) and the
 *   commit runs on a background thread: the JS thread is free right away (about 0.05 ms for 2000 views), the screen updates a few
 *   ms later. On Android the commit is currently synchronous.
 * - 'hook': the same, but the commit runs synchronously on the JS thread (about 4-8 ms for 2000 views).
 * - 'stock': React Native's UIManager::updateShadowTree (whole-tree walk). Benchmark baseline.
 * - 'fastAsync': one single-pass shadow-tree commit that clones only the touched nodes; the UI thread mounts it later.
 * - 'direct': update the native views immediately, the shadow tree catches up on the next React clone. Benchmark baseline.
 * - 'both': direct update now plus a single-pass commit. Benchmark baseline.
 * The last four are measurement baselines and are not supported for production use.
 */
export type ThemeStrategy = 'hook' | 'hookAsync' | 'stock' | 'fastAsync' | 'direct' | 'both';
/** Style subset supported in v0: visual-only props that don't need a Yoga layout pass. */
export type ThemedStyle = {
    backgroundColor?: ColorValue;
    borderColor?: ColorValue;
    /** Text colour (Text only). The engine rebuilds the paragraph state itself, so no layout pass is needed. */
    color?: ColorValue;
    opacity?: number;
};
export type ThemedStyles = Record<string, ThemedStyle>;
export declare function toNativePropsWith(props: Record<string, unknown>, colorKeys: readonly string[]): Record<string, unknown>;
export declare function toNativeProps(style: ThemedStyle): Record<string, unknown>;
export declare const ShadewindEngine: {
    /** Experimental: native tailwind-merge compatible class merge (see docs/ARCHITECTURE.md section 13). */
    loadClassTable(text: string): boolean;
    mergeClasses(...parts: string[]): string | undefined;
    /** Declares the theme names in order (native slot ids). Returns the slot count and whether all names fit. */
    configure(names: string[]): {
        maxThemes: number;
        ok: boolean;
    };
    register(ref: unknown, styles: ThemedStyles, renderTheme?: string): boolean;
    /** Registers with props already converted by toNativeProps (used by the public useThemed). */
    registerRaw(ref: unknown, native: Record<string, Record<string, unknown>>, renderTheme?: string): boolean;
    unregister(ref: unknown): void;
    /** Applies a theme to every registered view without rendering any React component. */
    setTheme(name: string, strategy?: ThemeStrategy): ThemeTimings;
    /** Measurement: clears the longest main-thread busy period (iOS only; starts the run loop observer on first call). */
    resetMainBusy(): void;
    /** Measurement: longest main-thread run loop busy period in ms since resetMainBusy (iOS only). */
    mainBusyMs(): number;
    /**
     * Optional hint that a theme switch is probably coming (call it from `onPressIn` of a theme toggle). It reads, off the
     * JS thread, the memory the switch will use, so a switch after a long idle does not pay for cold caches. Changes nothing.
     */
    prepare(): void;
    /** Debug only. Compares committed tree, nativeProps overlay and expected theme colours. */
    inspect(): InspectReport;
    getTheme(): string;
};
/**
 * Callback ref that registers a view's per-theme style on mount and unregisters on unmount.
 * Keep `styles` referentially stable (module constant or useMemo), or the view re-registers every render.
 */
export declare function useThemedRef(styles: ThemedStyles): (ref: unknown) => void;
//# sourceMappingURL=internal.d.ts.map