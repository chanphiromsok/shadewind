import { type ColorValue } from 'react-native';
/** loadStyleTable's answer: classes the table holds, classes it could not read (0 for a table styleTable.ts built). */
export type StyleTableLoad = {
    ok: boolean;
    classes: number;
    unsupported: number;
    error?: string;
};
/** Uniwind's resolveStyles result, as the native resolver returns it. */
export type ResolvedStyles = {
    styles: Record<string, unknown>;
    dependencies: number[];
    dependencySum: number;
    hasDataAttributes: boolean;
};
/** Debug report: where a stale colour comes from. All counts refer to backgroundColor of registered views. */
export type InspectReport = {
    theme: string;
    registered?: number;
    inTree?: number;
    notInTree?: number;
    /** Registered views inside a `display: none` subtree (a frozen screen): themed when they show, not compared. */
    hidden?: number;
    treeMatchesExpected?: number;
    /** iOS: registered views whose UIView.backgroundColor equals the expected theme colour. */
    nativePropsMatchExpected?: number;
    /** iOS: registered views whose layer was painted with the expected theme colour. */
    layerMatchesExpected?: number;
    samples?: string;
    /** Debug: hook state of registered views whose tree colour is not the expected one. */
    stale?: string;
};
/** One view a commit themed (shadewind/diagnostics). */
export type DiagnosticsUpdate = {
    tag: number;
    component: string;
    styleId: number;
    /** What the theme gives the view, as registered (colours as ARGB numbers). */
    props: Record<string, unknown>;
    /** The theme changed since the view was last themed; false: React replaced its props and the hook themed them again. */
    themeChange: boolean;
    /** A Text recoloured without a layout pass. */
    textWithoutLayout: boolean;
};
/** What the commit hook recorded (cpp/Diagnostics.hpp). `live`: registered views after the event. */
export type DiagnosticsEvent = {
    kind: 'registered' | 'unregistered' | 'unbound';
    live: number;
    tag: number;
    component: string;
    styleId: number;
} | {
    kind: 'commit';
    live: number;
    theme: string;
    themeChanged: boolean;
    reused: number;
    skipped: number;
    hidden: number;
    ms: number;
    updates: DiagnosticsUpdate[];
};
export type NativeDiagnostics = {
    /** Events lost because more were recorded between two reads than the native log keeps. */
    dropped: number;
    events: DiagnosticsEvent[];
};
/** Native-side breakdown of the engine's last commit, in milliseconds. */
export type ThemeTimings = {
    /** Views cloned with their theme's props. */
    views: number;
    /** A commit that changed nothing: the walk. */
    scanMs: number;
    /** A commit that changed something: walk, props and clones. */
    cloneMs: number;
    /** Part of cloneMs spent building the typed props. */
    propsMs: number;
    /** Views whose props came from the per-view cache instead of being rebuilt. */
    reused?: number;
    /** Nodes the walk visited. */
    visited?: number;
    /** Subtrees skipped because the previous commit had already themed them. */
    skipped?: number;
    /** `display: none` subtrees skipped (frozen screens, themed when they show). */
    hidden?: number;
    /** Why props were rebuilt and how text was recoloured (debug). */
    misses?: string;
    /** 'hookAsync': time from the previous setTheme call until the main thread finished mounting it. */
    visualMs?: number;
    /** 'hook': the commit; 'hookAsync': the previous background commit. */
    commitMs: number;
    /** What the JS thread paid inside the call. */
    totalMs: number;
};
/**
 * How a theme change reaches the screen. Unknown names throw.
 * - 'hookAsync' (default): the commit runs on a background thread, the JS thread is free right away. On Android it is synchronous
 *   for now.
 * - 'hook': the commit runs synchronously on the JS thread and is mounted at once.
 * - 'hookDeferred': the commit runs synchronously on the JS thread but its mount is queued on the RuntimeScheduler, so it lands
 *   with the React commit made in the same task (a Uniwind setTheme in a press handler): views the engine handles and views
 *   React re-renders change in the same frame. Only valid inside a JS task.
 * Either way the theme is applied inside a commit hook, so every later commit (React's too) keeps it.
 */
export type ThemeStrategy = 'hook' | 'hookAsync' | 'hookDeferred';
/** Preset names of an animated theme change. Add a name here and to `ThemeTransitionPreset` in cpp/ShadewindNative.hpp. */
export type ThemeTransitionPreset = 'fade' | 'blur';
/** What the native overlay is asked for: a preset and its length. */
export type NativeThemeTransition = {
    type: ThemeTransitionPreset;
    durationMs: number;
};
/** Style subset supported in v0: visual-only props that don't need a Yoga layout pass. */
export type ThemedStyle = {
    backgroundColor?: ColorValue;
    borderColor?: ColorValue;
    /** Text colour (Text only). The engine rebuilds the paragraph state itself, so no layout pass is needed. */
    color?: ColorValue;
    opacity?: number;
};
export type ThemedStyles = Record<string, ThemedStyle>;
export declare function toNativePropsWith(props: Record<string, unknown>, colorKeys: readonly string[]): Record<string, unknown>;
export declare function toNativeProps(style: ThemedStyle): Record<string, unknown>;
export declare const ShadewindEngine: {
    /** Experimental: native tailwind-merge compatible class merge (see docs/ARCHITECTURE.md section 13). */
    loadClassTable(text: string): boolean;
    mergeClasses(...parts: string[]): string | undefined;
    /**
     * Installs the class table src/uniwind/styleTable.ts builds (Uniwind's stylesheet evaluated per theme) and the global host
     * function `__swResolve` (resolveClasses without Nitro's method wrapper) in this runtime.
     */
    loadStyleTable(json: string): StyleTableLoad;
    /** Uniwind's resolveStyles for a className, natively from the loaded table, or undefined: resolve it with Uniwind's JS. */
    resolveClasses(className: string, theme: string, screenWidth: number, isPressed?: unknown, isFocused?: unknown, isDisabled?: unknown): ResolvedStyles | undefined;
    /** Declares the theme names in order (native slot ids). Returns the slot count and whether all names fit. */
    configure(names: string[]): {
        maxThemes: number;
        ok: boolean;
    };
    /**
     * Binds a mounted view (its ref) to per-theme styles. `renderTheme`: the theme its props were rendered with, known only on the
     * view's first attach. Registrations are sent to native after the commit, all at once. Returns false when the ref is not a
     * Fabric host view.
     */
    register(ref: unknown, styles: ThemedStyles, renderTheme?: string): boolean;
    /** Registers with props already converted by toNativeProps (used by the public useThemed). */
    registerRaw(ref: unknown, native: Record<string, Record<string, unknown>>, renderTheme?: string): boolean;
    /** Development only: names a styles object (as passed to register / registerRaw) in shadewind/diagnostics. */
    label(styles: object, label: string): void;
    /** The label of a style id, if one was given before its first registration. */
    labelOf(styleId: number): string | undefined;
    /**
     * Development diagnostics: which events the commit hook records (1 mounts, 2 unmounts, 4 updates; 0 off). Returns false when the
     * native build has no recorder (only Debug builds compile it in).
     */
    setDiagnostics(flags: number): boolean;
    /** Everything the commit hook recorded since the last call. Pending registrations are sent first, so their mounts are in it. */
    drainDiagnostics(): NativeDiagnostics;
    /** Whether `ref` is bound (registered or about to be). */
    isRegistered(ref: unknown): boolean;
    /**
     * Unbinds a view that stays mounted (a pressed Pressable, styles the engine cannot take any more): React's props are right for
     * it from now on. An unmount needs no call.
     */
    unregister(ref: unknown): void;
    /**
     * Applies a theme to every registered view without rendering any React component. Returns the timings of the switch in a build
     * with the dev tools (debug, or a release that opts in: cpp/DevTools.hpp), undefined otherwise.
     */
    setTheme(name: string, strategy?: ThemeStrategy, transition?: NativeThemeTransition): ThemeTimings | undefined;
    /** setTheme for a benchmark: the timings, or an error when this native build has none (a release without the dev tools). */
    setThemeTimed(name: string, strategy?: ThemeStrategy, transition?: NativeThemeTransition): ThemeTimings;
    /** Whether this native build has inspect / resetMainBusy / mainBusyMs and the setTheme timings (cpp/DevTools.hpp). */
    hasDevTools(): boolean;
    /** Measurement: clears the longest main-thread busy period (iOS only; starts the run loop observer on first call). */
    resetMainBusy(): void;
    /** Measurement: longest main-thread run loop busy period in ms since resetMainBusy (iOS only). */
    mainBusyMs(): number;
    /** Kept for compatibility; does nothing. */
    prepare(): void;
    /** Debug only. Compares the committed tree, UIKit and the expected theme colours. */
    inspect(): InspectReport;
    getTheme(): string;
};
/**
 * Callback ref that registers a view's per-theme style when it attaches. The registration outlives a Suspense/Activity hide (the
 * commit hook themes the view when it shows again) and goes away with the view.
 * Keep `styles` referentially stable (module constant or useMemo).
 */
export declare function useThemedRef(styles: ThemedStyles): (ref: unknown) => void;
//# sourceMappingURL=internal.d.ts.map