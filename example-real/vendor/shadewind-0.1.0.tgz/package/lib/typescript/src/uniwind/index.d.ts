export { installUniwind, registerPrebuiltStyleTable, type InstallResult, type PrebuiltTableMeta, } from './install.js';
/** Uniwind's class resolution in C++ (cpp/css/StyleResolver.hpp): status, rebuild, on / off. */
export { nativeResolver, type ResolverStatus } from './nativeResolver.js';
export { View } from './View.js';
export { Text } from './Text.js';
export { Pressable } from './Pressable.js';
export { TouchableOpacity } from './TouchableOpacity.js';
/** Debug only: why each className was or was not handed to the engine, and render counts (needs `__DEV__` or `globalThis.__SHADEWIND_DEBUG__ = true`). */
export { decisions, renders } from './useShadewindStyle.js';
export { withUniwind } from './withUniwind.js';
//# sourceMappingURL=index.d.ts.map