type Var = (vars: Record<string, unknown>) => unknown;
export type UniwindStyle = {
    entries: Array<[string, Var]>;
    minWidth: number;
    maxWidth: number;
    orientation: string | null;
    theme: string | null;
    rtl: boolean | null;
    dependencies: number[] | null;
    importantProperties: string[];
    complexity: number;
    active: boolean | null;
    focus: boolean | null;
    disabled: boolean | null;
    dataAttributes: Record<string, string> | null;
};
export type StyleTableInput = {
    stylesheet: Record<string, UniwindStyle[]>;
    /** UniwindStore.vars: the variables of each theme (prototype-chained to the shared ones). */
    varsByTheme: Record<string, Record<string, Var>>;
    themes: readonly string[];
    /**
     * UniwindStore.runtime, the `rt` of every value. `rt.lightDark` reads currentThemeName, so it is set to each theme while that
     * theme is evaluated; its changing fields are watched while the table is built (and restored after).
     */
    runtime: {
        currentThemeName: string;
    } & Record<string, unknown>;
    /**
     * Runtime fields fixed for a session on a device but unknown where the table is built (at Metro time: `pixelRatio`,
     * `hairlineWidth`). A value that reads one is treated like one reading a changing field, and its class is listed in
     * `deviceDependent`.
     */
    deviceFixed?: readonly string[];
};
export type StyleTable = {
    json: string;
    classes: number;
    fallback: number;
    /** Fallback classes with a value that read a `deviceFixed` field and no changing one: a table built on the device can hold them. */
    deviceDependent: string[];
};
export declare const buildStyleTable: (input: StyleTableInput) => StyleTable;
export {};
//# sourceMappingURL=styleTable.d.ts.map