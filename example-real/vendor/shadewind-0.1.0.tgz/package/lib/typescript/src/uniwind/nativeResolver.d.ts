import { type ResolvedStyles } from '../internal.js';
import { type UniwindStyle } from './styleTable.js';
type Getter = (vars: Record<string, unknown>) => unknown;
type Resolve = (classNames: string, componentProps: unknown, state: any, context: any) => ResolvedStyles;
type NativeResolve = (className: string, theme: string, screenWidth: number, isPressed?: unknown, isFocused?: unknown, isDisabled?: unknown) => ResolvedStyles | undefined;
/** The parts of Uniwind 1.12's UniwindStore the resolver reads (core/native/store.ts). */
export type ResolverStore = {
    stylesheet: Record<string, UniwindStyle[]>;
    vars: Record<string, Record<string, Getter>>;
    runtime: {
        currentThemeName: string;
        screen: {
            width: number;
        };
    } & Record<string, unknown>;
    resolveStyles: Resolve;
};
export type ResolverListener = {
    subscribe: (listener: () => void, dependencies: number[]) => () => void;
    getSnapshot?: (dependencies: number[]) => number;
};
/** A table built at bundle time, with the store state it was handed over with (registerPrebuiltStyleTable). */
export type PrebuiltTable = {
    json: string;
    /** classes Uniwind's JS keeps resolving */
    fallback: number;
    /** of those, classes left out because they read device-fixed runtime fields: a table built on the device can hold them */
    deviceDependent: number;
    stylesheet: unknown;
    vars: unknown;
    /** UniwindListener's Variables revision then: a change before install makes the table stale */
    variablesRevision: number | undefined;
};
export type ResolverStatus = {
    /** off: not installed or disabled; waiting: the table is not built yet; stale: built from other variables, rebuilding. */
    state: 'off' | 'waiting' | 'ready' | 'stale' | 'failed';
    /** where the table in use came from */
    source: 'prebuilt' | 'runtime' | null;
    /** classes in the table / classes Uniwind's JS keeps resolving (post-processed or runtime-dependent values, data / rtl variants). */
    classes: number;
    fallback: number;
    /** size of the table's JSON */
    tableBytes: number;
    /** JS thread time of the last build on the device (styleTable.ts; 0 for a prebuilt table) and of loading it natively (parse). */
    buildMs: number;
    loadMs: number;
    builds: number;
    /** cache misses of Uniwind's getStyles since launch: resolved natively / by Uniwind's JS */
    native: number;
    uniwind: number;
    error?: string;
};
/** Builds the table from the store now, on the device, and loads it natively (normally done when idle). */
export declare function rebuild(): ResolverStatus;
/** Called by install.ts with the table shadewind/metro built at bundle time (see registerPrebuiltStyleTable). */
export declare function offerPrebuiltTable(table: PrebuiltTable): void;
/**
 * Puts the native resolver in front of Uniwind's resolveStyles (once): with the prebuilt table if there is one for the store as it
 * is now, otherwise with a table built when the JS thread is idle. `variablesDependency`: Uniwind's StyleDependency.Variables.
 */
export declare function installNativeResolver(target: ResolverStore, uniwindListener: ResolverListener, variables: number): void;
export declare const nativeResolver: {
    status: () => ResolverStatus;
    /** Builds the table now, on the device (it is otherwise built when the JS thread is idle, unless a prebuilt one is in use). */
    rebuild: typeof rebuild;
    /** Off: every className goes to Uniwind's own resolveStyles again. Before install: no table is loaded or built either. */
    setEnabled(value: boolean): void;
    /** Benchmarks and checks: Uniwind's own resolveStyles and the native one, each called directly (no cache in front). */
    debug(): {
        store: ResolverStore | null;
        uniwind: Resolve | null;
        native: NativeResolve | null;
    };
};
export {};
//# sourceMappingURL=nativeResolver.d.ts.map