import type { ComponentType } from 'react';
import { type ViewProps } from 'react-native';
type Props = ViewProps & {
    className?: string;
};
export declare const View: ComponentType<Props>;
export default View;
//# sourceMappingURL=View.d.ts.map