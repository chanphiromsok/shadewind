import type { ComponentType } from 'react';
import { type PressableProps } from 'react-native';
type Props = PressableProps & {
    className?: string;
};
export declare const Pressable: ComponentType<Props>;
export default Pressable;
//# sourceMappingURL=Pressable.d.ts.map