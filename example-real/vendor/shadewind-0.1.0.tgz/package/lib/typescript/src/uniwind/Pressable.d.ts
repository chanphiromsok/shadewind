export { LightPressable as Pressable, LightPressable as default } from './LightPressable.js';
//# sourceMappingURL=Pressable.d.ts.map