import { type ComponentType } from 'react';
import { type TextProps } from 'react-native';
type Props = TextProps & {
    className?: string;
    selectionColorClassName?: string;
};
export declare const Text: ComponentType<Props>;
export default Text;
//# sourceMappingURL=Text.d.ts.map