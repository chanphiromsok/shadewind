import { type ComponentType } from 'react';
import { type TouchableOpacityProps } from 'react-native';
type Props = TouchableOpacityProps & {
    className?: string;
};
export declare const TouchableOpacity: ComponentType<Props>;
export default TouchableOpacity;
//# sourceMappingURL=TouchableOpacity.d.ts.map