import { type ComponentType } from 'react';
type Kind = 'view' | 'text';
type HostProps = Record<string, unknown>;
export type Aot = {
    /** The host component, or the Uniwind adapter when this className is not handled ahead of time. */
    readonly T: ComponentType<any>;
    /** Props for `T`: `{ style, ref }` (plus Text defaults), or `{ className }` for the adapter. */
    p(): HostProps;
};
export declare const aot: (className: string, kind: Kind) => Aot;
export {};
//# sourceMappingURL=aot.d.ts.map