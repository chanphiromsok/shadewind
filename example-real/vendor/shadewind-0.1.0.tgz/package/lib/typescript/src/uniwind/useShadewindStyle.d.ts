import { type Ref } from 'react';
import type { ThemedStyles } from '../internal.js';
type State = Record<string, boolean>;
/** Dev diagnostics: className -> 'engine' or why it fell back. Collected only when `__SHADEWIND_DEBUG__` or __DEV__. */
export declare const decisions: Map<string, string>;
/** Dev diagnostics: testID or className -> render count. */
export declare const renders: Map<string, number>;
export declare const useShadewindStyle: (className: string | undefined, props: Record<string, any>, state?: State) => {
    style: Record<string, unknown>;
    themed: ThemedStyles | null;
    onRegisterFailed: () => void;
};
/**
 * Callback ref: registers the view with the engine while `themed` is set, and forwards to the user's ref. The returned function
 * also carries `pause()` / `resume()`: a Pressable unbinds the view while it is pressed (React draws the pressed style) and
 * binds it again on release, with native calls only (no React state).
 */
export declare const useEngineRef: (themed: ThemedStyles | null, userRef: Ref<unknown> | undefined, onRegisterFailed?: () => void) => ((node: unknown) => void) & {
    pause: () => void;
    resume: () => void;
};
export {};
//# sourceMappingURL=useShadewindStyle.d.ts.map