import { type Ref } from 'react';
import type { ThemedStyles } from '../internal.js';
import { getInternals } from './install.js';
export type State = Record<string, boolean>;
export declare const ALL_STATE: State;
/** Dev diagnostics: className -> 'engine' or why it fell back. Collected only when `__SHADEWIND_DEBUG__` or __DEV__. */
export declare const decisions: Map<string, string>;
/** Dev diagnostics: testID or className -> render count. */
export declare const renders: Map<string, number>;
export declare const same: (a: unknown, b: unknown) => boolean;
export declare const renderThemeOf: WeakMap<object, string>;
export declare const renderThemeFor: (node: unknown, themed: object) => string | undefined;
type Resolved = ReturnType<NonNullable<ReturnType<typeof getInternals>>['UniwindStore']['getStyles']>;
type Plan = {
    themed: ThemedStyles | null;
    reason: string;
};
export declare const cachedPlan: (className: string | undefined, props: Record<string, any>, state: State | undefined, context: {
    scopedTheme: string | null;
}, current: Resolved, hasInlineOverlap: boolean) => Plan;
export declare const nonThemeDeps: (current: Resolved, theme: number) => number[];
export declare const useShadewindStyle: (className: string | undefined, props: Record<string, any>, state?: State, accentClassName?: string) => {
    style: Record<string, unknown>;
    themed: ThemedStyles | null;
    onRegisterFailed: () => void;
    accentColor: string | undefined;
};
/**
 * The ref for an engine view: registers on attach and forwards to the user's ref. A view that is not bound gets the user's own
 * ref back unchanged, so React attaches nothing for it. With `pausable` the ref also carries `pause()` / `resume()` (Pressable).
 */
export declare const useEngineRef: (themed: ThemedStyles | null, userRef: Ref<unknown> | undefined, onRegisterFailed?: () => void, pausable?: boolean) => any;
export {};
//# sourceMappingURL=useShadewindStyle.d.ts.map