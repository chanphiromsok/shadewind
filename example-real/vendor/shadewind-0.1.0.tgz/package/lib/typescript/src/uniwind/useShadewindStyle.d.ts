import { type Ref } from 'react';
import type { ThemedStyles } from '../internal.js';
type State = Record<string, boolean>;
/** Dev diagnostics: className -> 'engine' or why it fell back. Collected only when `__SHADEWIND_DEBUG__` or __DEV__. */
export declare const decisions: Map<string, string>;
/** Dev diagnostics: testID or className -> render count. */
export declare const renders: Map<string, number>;
export declare const useShadewindStyle: (className: string | undefined, props: Record<string, any>, state?: State) => {
    style: Record<string, unknown>;
    themed: ThemedStyles | null;
    onRegisterFailed: () => void;
};
/**
 * The ref for an engine view: registers on attach and forwards to the user's ref. A view that is not bound gets the user's own
 * ref back unchanged, so React attaches nothing for it. The ref also carries `pause()` / `resume()` (Pressable).
 */
export declare const useEngineRef: (themed: ThemedStyles | null, userRef: Ref<unknown> | undefined, onRegisterFailed?: () => void) => any;
export {};
//# sourceMappingURL=useShadewindStyle.d.ts.map