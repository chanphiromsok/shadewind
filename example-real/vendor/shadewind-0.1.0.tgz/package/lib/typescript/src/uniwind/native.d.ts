import type { ComponentType } from 'react';
declare const NativeView: ComponentType<any>;
declare const NativeText: ComponentType<any>;
declare const TextAncestorContext: import("react").Context<boolean>;
export { NativeView, NativeText, TextAncestorContext };
export declare const withUserStyle: (resolved: unknown, user: unknown) => any;
export declare const viewIsPlain: (props: Record<string, unknown>) => boolean;
export declare const styleIsPlain: (style: unknown) => boolean;
export declare const textIsPlain: (props: Record<string, unknown>, resolved: unknown) => boolean;
//# sourceMappingURL=native.d.ts.map