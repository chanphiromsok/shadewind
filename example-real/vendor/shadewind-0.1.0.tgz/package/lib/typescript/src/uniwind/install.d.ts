import type { ThemedStyles } from '../internal.js';
export type InstallResult = {
    active: boolean;
    reason?: string;
};
type Internals = {
    UniwindStore: {
        vars: Record<string, unknown>;
        runtime: {
            currentThemeName: string;
        };
        getStyles: (className: string | undefined, props: Record<string, any>, state: any, context: any) => {
            styles: Record<string, unknown>;
            dependencies: number[];
            hasDataAttributes?: boolean;
        };
    };
    UniwindListener: {
        subscribe: (listener: () => void, dependencies: number[]) => () => void;
        getSnapshot?: (dependencies: number[]) => number;
    };
    StyleDependency: {
        Theme: number;
        Variables: number;
    };
};
export declare const getInternals: () => Internals | null;
/**
 * Connects the engine to Uniwind. Safe to call many times and never throws: when it returns `{ active: false }` every
 * component keeps Uniwind's own theme subscription and behaves exactly like plain Uniwind.
 */
export declare function installUniwind(): InstallResult;
/** What shadewind/metro writes next to a prebuilt table (metro-babel-transformer.cjs). */
export type PrebuiltTableMeta = {
    uniwind: string;
    platform: string;
    themes: string[];
    fingerprint: string | null;
    fallback: number;
    deviceDependent: number;
};
/**
 * Called by the code shadewind/metro appends to Uniwind's CSS module, right after Uniwind loaded the stylesheet: the class table
 * built at bundle time. It is kept with the store's stylesheet, variables and variables revision of this moment, and used at install
 * only if they are still the store's (and the platform and Uniwind version are the ones it was built for). Never throws.
 */
export declare function registerPrebuiltStyleTable(json: string, meta: PrebuiltTableMeta): void;
export type { ThemedStyles };
//# sourceMappingURL=install.d.ts.map