import type { ThemedStyles } from '../internal.js';
export type InstallResult = {
    active: boolean;
    reason?: string;
};
type Internals = {
    UniwindStore: {
        vars: Record<string, unknown>;
        runtime: {
            currentThemeName: string;
        };
        getStyles: (className: string | undefined, props: Record<string, any>, state: any, context: any) => {
            styles: Record<string, unknown>;
            dependencies: number[];
            hasDataAttributes?: boolean;
        };
    };
    UniwindListener: {
        subscribe: (listener: () => void, dependencies: number[]) => () => void;
    };
    StyleDependency: {
        Theme: number;
    };
};
export declare const getInternals: () => Internals | null;
/**
 * Connects the engine to Uniwind. Safe to call many times and never throws: when it returns `{ active: false }` every
 * component keeps Uniwind's own theme subscription and behaves exactly like plain Uniwind.
 */
export declare function installUniwind(): InstallResult;
export type { ThemedStyles };
//# sourceMappingURL=install.d.ts.map