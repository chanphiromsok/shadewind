import { type ComponentType } from 'react';
type AnyProps = Record<string, any>;
export declare const withUniwind: (Component: ComponentType<any>, options?: Record<string, unknown>) => ComponentType<AnyProps> | {
    (props: AnyProps): import("react").ReactElement<AnyProps, string | import("react").JSXElementConstructor<any>>;
    displayName: string;
};
export default withUniwind;
//# sourceMappingURL=withUniwind.d.ts.map