import { type ComponentType } from 'react';
import { type PressableProps } from 'react-native';
type Props = PressableProps & {
    className?: string;
};
export declare const LightPressable: ComponentType<Props>;
export default LightPressable;
//# sourceMappingURL=LightPressable.d.ts.map