import { type ComponentType, type Ref, type RefCallback } from 'react';
import { type ColorValue, type StyleProp, type TextProps, type TextStyle, type ViewProps, type ViewStyle } from 'react-native';
import { type ThemeTransitionPreset } from './internal.js';
export type { ThemeTransitionPreset };
/** Augment to type theme names: `declare module 'shadewind' { interface Register { themes: 'light' | 'dark' } }`. */
export interface Register {
}
export type ThemeName = Register extends {
    themes: infer T extends string;
} ? T : string;
export type ThemeKey = 'backgroundColor' | 'borderColor' | 'color';
export type ThemedStyle = {
    backgroundColor?: ColorValue;
    borderColor?: ColorValue;
    /** Text colour (Text only). */
    color?: ColorValue;
};
export type ThemedStyles = Readonly<Partial<Record<ThemeName, ThemedStyle>>>;
export type Capabilities = Readonly<{
    maxThemes: number;
    supportedKeys: readonly ThemeKey[];
    asyncCommit: boolean;
    platform: 'ios' | 'android';
}>;
export type ShadewindErrorCode = 'UNKNOWN_THEME' | 'TOO_MANY_THEMES' | 'DUPLICATE_THEME' | 'NOT_CONFIGURED' | 'UNKNOWN_TRANSITION';
export declare class ShadewindError extends Error {
    code: ShadewindErrorCode;
    constructor(code: ShadewindErrorCode, message: string);
}
/**
 * An animated theme change: a snapshot of the old screen is laid over the app, the theme is switched underneath it, and the
 * snapshot fades out once the new theme is mounted ('fade'), or first blurs for half the time and then fades ('blur'; Android
 * below 12 fades without the blur). It never takes touches. Skipped (instant switch) when the OS asks for reduced
 * motion, when the app is in the background or has no window. Default: no transition.
 */
export type ThemeTransition = {
    type: ThemeTransitionPreset;
    /** Length of the whole transition in ms (default 250, at most 2000). 0 or less: instant. */
    durationMs?: number;
};
export type SetThemeOptions = {
    /** Overrides the default set by `configure` / `setDefaultTransition`; `false` forces an instant switch. */
    transition?: ThemeTransition | false;
};
export type ConfigureOptions = {
    themes: readonly ThemeName[];
    initialTheme: ThemeName;
    /** What to do when a binding cannot use the fast path (it renders through React instead). Default 'warn'. */
    onUnsupported?: 'warn' | 'throw' | 'silent';
    /** Transition for every theme change that does not pass its own (Uniwind's setTheme included). Default: none. */
    transition?: ThemeTransition;
};
export declare const capabilities: Capabilities;
/** Declares the themes. Call once, before the first render. A different list needs a reload (native state is per process). */
export declare function configure(options: ConfigureOptions): void;
export declare function getTheme(): ThemeName;
export declare function subscribe(listener: (theme: ThemeName) => void): () => void;
/** Sets the transition used by every theme change that passes none of its own (also Uniwind's). `undefined` clears it. */
export declare function setDefaultTransition(transition: ThemeTransition | undefined): void;
/**
 * Switches every bound view without rendering React components. Rapid calls: the last one wins.
 * `setTheme('dark', { transition: { type: 'fade', durationMs: 250 } })` cross-fades instead of switching at once; `type: 'blur'`
 * blurs the old screen first.
 */
export declare function setTheme(name: ThemeName, options?: SetThemeOptions): void;
/**
 * For shadewind/uniwind: routes setTheme through Uniwind's setTheme, so Uniwind and the engine never hold different themes.
 * Not part of the public API.
 * @internal
 */
export declare function setThemeDriver(driver: ((name: string) => void) | null): void;
/**
 * For shadewind/uniwind: a Uniwind theme change, applied by the React commit that Uniwind's own subscribers trigger (see
 * ThemeStrategy 'hookDeferred'), so the engine's views and React's change together. Not part of the public API.
 * @internal
 */
export declare function applyUniwindTheme(name: ThemeName): void;
/** Follows the OS appearance. An explicit setTheme() stops following. Returns an unsubscribe. */
export declare function followSystem(map?: {
    light: ThemeName;
    dark: ThemeName;
}): () => void;
/** The current theme as React state, for UI the engine does not update (status bar, navigation theme). */
export declare function useTheme(): ThemeName;
export declare function mergeRefs<T>(...refs: Array<Ref<T> | undefined>): RefCallback<T>;
export type UseThemedResult<T extends object> = {
    ref: (instance: any) => void;
    /** Style of the current theme, so mount, re-render and fallback always show the right colour. */
    style: T;
    /** true: the engine updates this view; false: it re-renders through React on a switch. */
    engine: boolean;
};
/**
 * Binds one view to per-theme styles. Pass `ref` and `style` to a host component.
 * Anything the engine cannot handle falls back to a normal React render for this view.
 */
export declare function useThemed<T extends object = ViewStyle>(styles: ThemedStyles, options?: {
    forceFallback?: string;
}): UseThemedResult<T>;
export type ThemedViewProps = ViewProps & {
    themed: ThemedStyles;
};
export type ThemedTextProps = TextProps & {
    themed: ThemedStyles;
};
export declare const ThemedView: ComponentType<ThemedViewProps & {
    style?: StyleProp<ViewStyle>;
}>;
export declare const ThemedText: ComponentType<ThemedTextProps & {
    style?: StyleProp<TextStyle>;
}>;
export type UseThemedPropsResult<T extends object> = {
    ref: (instance: any) => void;
    /** The props of the current theme, for the render that is happening now. Never subscribes: no React state is involved. */
    props: T;
};
/**
 * Themes props that are not `style` (a gradient's `colors`, a native view's `color`, ...) without any React state:
 * the values per theme are handed to the engine, which rewrites the host node's props inside the commit on every switch.
 *
 * `colorKeys` names the props that hold colours (a colour or an array of colours); they are converted to native colours.
 * The component re-renders for other reasons as usual and then simply reads the current theme again.
 */
export declare function useThemedProps<T extends Record<string, unknown>>(valuesByTheme: Readonly<Partial<Record<ThemeName, T>>>, options?: {
    colorKeys?: readonly string[];
}): UseThemedPropsResult<T>;
export type ClassValue = string | number | boolean | null | undefined | readonly ClassValue[] | {
    readonly [key: string]: unknown;
};
type CnFallback = (...inputs: ClassValue[]) => string;
/**
 * Installs the native class merge.
 *
 * `table` is the text generated by `npx shadewind-cn-table <srcDir>` (tailwind-merge is the oracle, so for every token in the
 * table the result is byte-identical to `twMerge(clsx(...))`). `fallback` (normally `(...a) => twMerge(clsx(a))`) is used for
 * any call that contains a token the table does not know, so the output never differs from the reference.
 * Returns false when the native module could not load the table.
 */
export declare function configureCn(options: {
    table: string;
    fallback?: CnFallback;
}): boolean;
/**
 * `twMerge(clsx(...inputs))`, computed natively for every token the table knows.
 *
 * Fast path: up to four arguments that are each a string or falsy go to the native function directly, with no array
 * allocation. Anything else (arrays, objects, numbers) is flattened first.
 */
export declare function cn(...inputs: ClassValue[]): string;
//# sourceMappingURL=index.d.ts.map