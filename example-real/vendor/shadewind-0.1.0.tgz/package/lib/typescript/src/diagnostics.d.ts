import { type DiagnosticsUpdate } from './internal.js';
export type DiagnosticsOptions = {
    /** Log every view bound to the engine: `Shadewind (5): 🟢 ShadowNodeRegistered for tag 42 (View) and className: "..."`. */
    reportMounts?: boolean;
    /**
     * Log every bound view that leaves: 🟡 when it was unmounted and released (reported at a later commit, once React Native and the
     * JS garbage collector let go of it), 🟠 when a mounted view was unbound and left to React (pressed, or its style no longer suits
     * the engine).
     */
    reportUnmounts?: boolean;
    /** Log every commit that themed views: which views, with which props. */
    reportUpdates?: boolean;
};
/**
 * Logs what the engine does to the shadow tree. Calling it again replaces the options; all false turns diagnostics off.
 * Screens that stay mounted keep their views registered (inactive tabs, frozen screens, suspended content), so leaving a tab does
 * not lower the count.
 */
export declare function enableDiagnostics(options?: DiagnosticsOptions): void;
/** Stops logging. What was recorded and not printed yet is dropped. */
export declare function disableDiagnostics(): void;
/** Prints what was recorded since the last call (the poll does this on its own; useful right before a test assertion). */
export declare function flushDiagnostics(): void;
export declare function formatUpdate(update: DiagnosticsUpdate): string;
/** ARGB as processColor makes it (unsigned on iOS, signed on Android) -> `#RRGGBB`, or `#RRGGBBAA` when not opaque. */
export declare function formatColor(value: number): string;
//# sourceMappingURL=diagnostics.d.ts.map